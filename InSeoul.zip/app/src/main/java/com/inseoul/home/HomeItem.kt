package com.inseoul.home

data class HomeItem(
    val title:String,
    val content:String
) {
}