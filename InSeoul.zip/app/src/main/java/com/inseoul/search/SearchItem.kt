package com.inseoul.search

data class SearchItem(
    val title:String,
    val preview:String
) {
}