package com.inseoul.timeline

data class TimeLineItem (
    val title:String,
    val preview:String
){
}